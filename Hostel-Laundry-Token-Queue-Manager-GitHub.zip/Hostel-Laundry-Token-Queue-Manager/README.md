# Hostel Laundry Token & Queue Manager

An 8086 Assembly Language project that simulates a hostel laundry order management system using **EMU8086**.

## Project Overview

The system manages laundry orders using a **FIFO (First-In, First-Out) circular queue**. Users can add laundry orders, process the oldest order, and view the current queue summary.

## Platform & Technology

- **Processor:** Intel 8086
- **Language:** 8086 Assembly Language
- **IDE/Emulator:** EMU8086
- **Memory model:** SMALL
- **Operating environment:** DOS-style `INT 21H` services

## Features

1. Add a laundry order
   - Hostel room number: 1–999
   - Service selection
   - Number of clothes: 1–20
   - Automatic bill calculation
   - Automatic token generation

2. Process the next order
   - Uses FIFO queue logic
   - Removes the oldest pending order
   - Updates pending revenue

3. View queue summary
   - Pending order count
   - Pending bill total
   - Details of every pending order

4. Input validation
   - Menu option validation
   - Room number validation
   - Service validation
   - Clothes quantity validation
   - Numeric input handling

## Service Rates

| Service | Rate |
|---|---:|
| Wash only | 40 BDT / cloth |
| Wash and iron | 70 BDT / cloth |
| Express service | 100 BDT / cloth |

## Data Structures

The project uses a circular queue with parallel arrays:

- `TOKEN_QUEUE` – stores token numbers
- `ROOM_QUEUE` – stores room numbers
- `SERVICE_QUEUE` – stores service codes
- `CLOTH_QUEUE` – stores clothes quantities
- `BILL_QUEUE` – stores calculated bills

Queue control variables:

- `QUEUE_COUNT`
- `HEAD_INDEX`
- `TAIL_INDEX`
- `NEXT_TOKEN`
- `PENDING_REVENUE`

## How to Run in EMU8086

1. Open **EMU8086**.
2. Create/open an Assembly source file.
3. Copy the contents of `main.asm` into the source editor.
4. Compile/assemble the program.
5. Run the program in the emulator.
6. Use the menu:
   - `1` → Add a laundry order
   - `2` → Process the next order
   - `3` → View queue summary
   - `4` → Exit

## Example Workflow

```text
1. Add a laundry order
   Room: 205
   Service: 2 (Wash and iron)
   Clothes: 5

   Bill = 5 × 70 = 350 BDT

2. Add another order

3. View queue summary

4. Process the next order
   The oldest order is processed first (FIFO).
```

## Concepts Demonstrated

- 8086 registers and instructions
- Procedures and `CALL` / `RET`
- Stack operations (`PUSH` / `POP`)
- Arrays
- Circular queue
- FIFO scheduling
- Arithmetic operations
- Conditional branching
- Loops
- DOS interrupts
- Keyboard input
- Console output
- Input validation
- Modular program design

## Project Structure

```text
Hostel-Laundry-Token-Queue-Manager/
│
├── main.asm
├── README.md
├── .gitignore
└── screenshots/
    └── output.png
```

## Author / Team

Add the actual team members and student IDs here.

Example:

- Tanima Riya — Student ID: YOUR_ID
- Member 2 — Student ID: MEMBER_ID
- Member 3 — Student ID: MEMBER_ID

> If this is a group project, list each member and clearly state each person's contribution.

## Academic Note

This project was developed as an academic project for learning 8086 microprocessor programming and Assembly Language concepts.

## License

This project is intended for educational and academic use.
